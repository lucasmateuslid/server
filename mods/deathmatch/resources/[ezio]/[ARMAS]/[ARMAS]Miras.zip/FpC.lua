addCommandHandler("mira1", function(source)
	exports["infobox"]:addBox(source, "info", "Voce Selecionou a mira 1")
end)

addCommandHandler("mira2", function(source)
	exports["infobox"]:addBox(source, "info", "Voce Selecionou a mira 2")
end)

addCommandHandler("mira3", function(source)
	exports["infobox"]:addBox(source, "info", "Voce Selecionou a mira 3")
end)

addCommandHandler("mira4", function(source)
	exports["infobox"]:addBox(source, "info", "Voce Selecionou a mira 4")
end)

addCommandHandler("mira5", function(source)
	exports["infobox"]:addBox(source, "info", "Voce Selecionou a mira 5")
end)

addCommandHandler("mira6", function(source)
	exports["infobox"]:addBox(source, "info", "Voce Selecionou a mira 6")
end)