--[[


                ██████╗ ███████╗
                ██╔══██╗██╔════╝
                ██║  ██║███████╗
                ██║  ██║╚════██║
                ██████╔╝███████║
                ╚═════╝ ╚══════╝
           Copyright 2021 | d1ogo#0001
           
--]]

config = {
    ["Options"] = {
        ["ElementFuel"] = "Gasolina"; -- Element data da gasolina.
        ["MaxVelocity"] = 400; -- Velocidade máxima do velocimetro.
    };
    ["Design"] = {
        [1] = {57, 56, 57}; -- Cor do velocimetro.
    };
}