local rangeSet= setWeaponProperty (31,"poor","weapon_range",85)if(rangeSet)then outputChatBox ("")end    
  