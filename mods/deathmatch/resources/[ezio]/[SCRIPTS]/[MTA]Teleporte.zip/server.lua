﻿function tele (thePlayer)
	setElementPosition ( thePlayer, 1727.1397705078, 1615.9514160156, 9.9772815704346 )
	outputChatBox ('#424242[ #FFFFFFBGR #424242] - #FFFFFF' .. getPlayerName(thePlayer) .. ' #ffffffFoi Para o Aeroporto de LV #424242[ /lv ]', root, 255, 255, 255, true)
end
addCommandHandler ( "lv", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, 1955.9456787109, -2178.2778320314, 13.546875 )
	outputChatBox ('#424242[ #FFFFFFBGR #424242] - #FFFFFF' .. getPlayerName(thePlayer) .. ' #ffffffFoi Para o Aeroporto de LS #424242[ /ls ]', root, 255, 255, 255, true)
end
addCommandHandler ( "ls", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, -1670.2022705078, -547.45129394531, 11.5078125 )
	outputChatBox ('#424242[ #FFFFFFBGR #424242] - #FFFFFF' .. getPlayerName(thePlayer) .. ' #ffffffFoi Para o Aeroporto de SF #424242[ /sf ]', root, 255, 255, 255, true)
end
addCommandHandler ( "sf", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, 1181.7885742188, -1323.3103027344, 13.582154273987 )
	outputChatBox ('#424242[ #FFFFFFBGR #424242] - #FFFFFF' .. getPlayerName(thePlayer) .. ' #ffffffFoi Para o Hospital Principal #424242[ /hp1 ]', root, 255, 255, 255, true)
end
addCommandHandler ( "hp1", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, 1997.042, -1449.741, 13.560 )
	outputChatBox ('#424242[ #FFFFFFBGR #424242] - #FFFFFF' .. getPlayerName(thePlayer) .. ' #ffffffFoi Para o Hospital do CJ #424242[ /hp2 ]', root, 255, 255, 255, true)
end
addCommandHandler ( "hp2", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, 1545.9736328125, -1675.4505615234, 13.561408996582 )
	outputChatBox ('#424242[ #FFFFFFBGR #424242] - #FFFFFF' .. getPlayerName(thePlayer) .. ' #ffffffFoi Para a Delegacia de LS #424242[ /dp ]', root, 255, 255, 255, true)
end
addCommandHandler ( "dp", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, 1409.9390869141, -1881.3250732422, 13.546875 )
	outputChatBox ('#424242[ #FFFFFFBGR #424242] - #FFFFFF' .. getPlayerName(thePlayer) .. ' #ffffffFoi Para a Favela do Jacaré #424242[ /jacare ]', root, 255, 255, 255, true)
end
addCommandHandler ( "jacare", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, 2295.482,-1157.608,26.655 )
	outputChatBox ('#424242[ #FFFFFFBGR #424242] - #FFFFFF' .. getPlayerName(thePlayer) .. ' #ffffffFoi Para a Favela da CDD #424242[ /cdd ]', root, 255, 255, 255, true)
end
addCommandHandler ( "cdd", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, -1478.328, 1489.310, 8.250 )
	outputChatBox ('#424242[ #FFFFFFBGR #424242] - #FFFFFF' .. getPlayerName(thePlayer) .. ' #ffffffFoi Para o Navio #424242[ /navio ]', root, 255, 255, 255, true)
end
addCommandHandler ( "navio", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, 2799.704, -2443.342, 14.314 )
	outputChatBox ('#424242[ #FFFFFFBGR #424242] - #FFFFFF' .. getPlayerName(thePlayer) .. ' #ffffffFoi Para o Treinamento #424242[ /**** ]', root, 255, 255, 255, true)
end
addCommandHandler ( "trneb", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, -113.587, 2445.712, 14.423 )
	outputChatBox ('#424242[ #FFFFFFBGR #424242] - #FFFFFF' .. getPlayerName(thePlayer) .. ' #ffffffFoi Para o Treinamento 01 #424242[ /trn1 ]', root, 255, 255, 255, true)
end
addCommandHandler ( "trn1", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, -1628.058, 2718.100, 57.772 )
	outputChatBox ('', root, 255, 255, 255, true)
end
addCommandHandler ( "1v", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, -2410.853, -2193.641, 33.289 )
	outputChatBox ('', root, 255, 255, 255, true)
end
addCommandHandler ( "2v", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, 1811.710, 2702.645, 10.820 )
	outputChatBox ('', root, 255, 255, 255, true)
end
addCommandHandler ( "1r", tele )

function tele (thePlayer)
	setElementPosition ( thePlayer, -2325.044, -2168.937, 38.633 )
	outputChatBox ('', root, 255, 255, 255, true)
end
addCommandHandler ( "2r", tele )