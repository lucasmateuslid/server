
function Skin01F()
   if getElementModel(source) == 280 then
   else
   setElementModel(source,280)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 280")
   end
end
addEvent("EventSkin01",true)
addEventHandler("EventSkin01",getRootElement(),Skin01F)

-----------------------------------------------------------------------------------------------

function Skin02F()
 if getElementModel(source) == 281 then
   else
   setElementModel(source,281)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 281")
   end
end
addEvent("EventSkin02",true)
addEventHandler("EventSkin02",getRootElement(),Skin02F)

-----------------------------------------------------------------------------------------

function Skin03F()
 if getElementModel(source) == 282 then
   else
   setElementModel(source,282)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 282")
   end
end
addEvent("EventSkin03",true)
addEventHandler("EventSkin03",getRootElement(),Skin03F)

------------------------------------------------------------------------------------------------------------------

function Skin04F()
 if getElementModel(source) == 283 then
   else
   setElementModel(source,283)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 283")
   end
end
addEvent("EventSkin04",true)
addEventHandler("EventSkin04",getRootElement(),Skin04F)

---------------------------------------------------------------------------------------------------------------

function Skin05F()
 if getElementModel(source) == 284 then
   else
   setElementModel(source,284)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 284")
   end
end
addEvent("EventSkin05",true)
addEventHandler("EventSkin05",getRootElement(),Skin05F)

----------------------------------------------------------------------------------------------------------------------------

function Skin06F()
 if getElementModel(source) == 285 then
   else
   setElementModel(source,285)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 285")
   end
end
addEvent("EventSkin06",true)
addEventHandler("EventSkin06",getRootElement(),Skin06F)

--------------------------------------------------------------------------------------------------------------------------

function Skin07F()
 if getElementModel(source) == 286 then
   else
   setElementModel(source,286)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 286")
   end
end
addEvent("EventSkin07",true)
addEventHandler("EventSkin07",getRootElement(),Skin07F)

------------------------------------------------------------------------------------------------------------------

function Skin08F()
 if getElementModel(source) == 287 then
   else
   setElementModel(source,287)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 287")
   end
end
addEvent("EventSkin08",true)
addEventHandler("EventSkin08",getRootElement(),Skin08F)

--------------------------------------------------------------------------------------------------------------------

function Skin09F()
 if getElementModel(source) == 154 then
   else
   setElementModel(source,154)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 154")
   end
end
addEvent("EventSkin09",true)
addEventHandler("EventSkin09",getRootElement(),Skin09F)

-----------------------------------------------------------------------------------------------------

function Skin010F()
 if getElementModel(source) == 292 then
   else
   setElementModel(source,293)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 293")
   end
end
addEvent("EventSkin010",true)
addEventHandler("EventSkin010",getRootElement(),Skin010F)

-------------------------------------------------------------------------------

function Skin011F()
 if getElementModel(source) == 290 then
   else
   setElementModel(source,292)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 292")
   end
end
addEvent("EventSkin011",true)
addEventHandler("EventSkin011",getRootElement(),Skin011F)

-----------------------------------------------------------------------------------------


function Skin012F()
 if getElementModel(source) == 291 then
   else
   setElementModel(source,291)
   exports["infobox"]:addBox(source, "success", "Você Pegou a Skin do ID 291")
   end
end
addEvent("EventSkin012",true)
addEventHandler("EventSkin012",getRootElement(),Skin012F)

------------------------------------------------------------------------------------------------------
function RemovArmasF()
   if getElementModel(source) == 201 then
     else
     setElementModel(source,293)
     exports["infobox"]:addBox(source, "success", "Armas Removidas")
     end
  end
  addEvent("EventRemovArmas",true)
  addEventHandler("EventRemovArmas",getRootElement(),RemovArmasF)