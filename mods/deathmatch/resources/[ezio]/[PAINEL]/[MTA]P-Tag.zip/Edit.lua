staffACLs =
{
	"Staff",
}

ACLS = {
	"EB",
	"FN",
	"PF",
	"FT",
	"ROTA",
	"PMESP",
	"PMERJ",
	"Policia Civil",
}
