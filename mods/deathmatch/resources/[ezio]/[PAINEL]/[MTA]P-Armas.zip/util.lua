bindKey("F5", "down", function()
	local sound = playSound("blip.wav") 
	setSoundVolume(sound, 1) 
end)