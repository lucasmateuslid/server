﻿--[[
    _CMDs  >>  Comandos que serão bloqueados para o jogador que estiver em evento.
    _KEYs  >>  Teclas que serão bloqueadas para o jogador que estiver em evento.
    
    ** Alguns comandos e teclas não irão funcionar.
]]
ENABLE_HEDIT = false;

_CMDs = {

"give",
"au",
"addupgrade",

}

_KEYs = {

"F1",
"F2",
"F3",
"F4",
"F5",
"F6",
"F7",
"F9",

}